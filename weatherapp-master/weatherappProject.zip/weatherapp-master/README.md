# Weather App

The weather app called **Weather in** designed with HTML, CSS, Bootstrap and Javascript for educational purposes. That's all you need to know.
 
![weather app js](https://user-images.githubusercontent.com/65046391/82387841-fa32e000-9a2f-11ea-9bce-2a857bce5247.jpg)
